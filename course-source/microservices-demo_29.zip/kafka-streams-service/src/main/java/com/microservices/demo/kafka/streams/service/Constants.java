package com.microservices.demo.kafka.streams.service;

public class Constants {
    public static final String NA = "N/A";
}
